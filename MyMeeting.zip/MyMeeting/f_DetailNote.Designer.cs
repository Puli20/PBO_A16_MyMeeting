﻿namespace MyMeeting
{
    partial class f_DetailNote
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label4 = new System.Windows.Forms.Label();
            this.lb_totalChar = new System.Windows.Forms.Label();
            this.btn_hapus = new System.Windows.Forms.Button();
            this.btn_simpan = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.cb_kategori = new System.Windows.Forms.ComboBox();
            this.tb_nama = new System.Windows.Forms.TextBox();
            this.tb_isi = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_tambah = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.BackColor = System.Drawing.Color.Black;
            this.label4.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(101, 300);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 20);
            this.label4.TabIndex = 9;
            this.label4.Text = "/ 1000 karakter";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // lb_totalChar
            // 
            this.lb_totalChar.AutoSize = true;
            this.lb_totalChar.BackColor = System.Drawing.Color.Black;
            this.lb_totalChar.Font = new System.Drawing.Font("Roboto", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.lb_totalChar.ForeColor = System.Drawing.Color.White;
            this.lb_totalChar.ImageAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.lb_totalChar.Location = new System.Drawing.Point(55, 300);
            this.lb_totalChar.Name = "lb_totalChar";
            this.lb_totalChar.Size = new System.Drawing.Size(49, 20);
            this.lb_totalChar.TabIndex = 10;
            this.lb_totalChar.Text = "1000";
            this.lb_totalChar.TextAlign = System.Drawing.ContentAlignment.TopRight;
            this.lb_totalChar.Click += new System.EventHandler(this.lb_totalChar_Click);
            // 
            // btn_hapus
            // 
            this.btn_hapus.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_hapus.Location = new System.Drawing.Point(14, 328);
            this.btn_hapus.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_hapus.Name = "btn_hapus";
            this.btn_hapus.Size = new System.Drawing.Size(97, 47);
            this.btn_hapus.TabIndex = 11;
            this.btn_hapus.Text = "Hapus";
            this.btn_hapus.UseVisualStyleBackColor = true;
            this.btn_hapus.Click += new System.EventHandler(this.btn_hapus_Click);
            // 
            // btn_simpan
            // 
            this.btn_simpan.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_simpan.Location = new System.Drawing.Point(119, 328);
            this.btn_simpan.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_simpan.Name = "btn_simpan";
            this.btn_simpan.Size = new System.Drawing.Size(97, 47);
            this.btn_simpan.TabIndex = 12;
            this.btn_simpan.Text = "Simpan";
            this.btn_simpan.UseVisualStyleBackColor = true;
            this.btn_simpan.Click += new System.EventHandler(this.btn_simpan_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.Color.Black;
            this.label1.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(9, 13);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 24);
            this.label1.TabIndex = 13;
            this.label1.Text = "Nama";
            // 
            // cb_kategori
            // 
            this.cb_kategori.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.cb_kategori.FormattingEnabled = true;
            this.cb_kategori.Location = new System.Drawing.Point(14, 113);
            this.cb_kategori.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cb_kategori.Name = "cb_kategori";
            this.cb_kategori.Size = new System.Drawing.Size(202, 32);
            this.cb_kategori.TabIndex = 14;
            // 
            // tb_nama
            // 
            this.tb_nama.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_nama.Location = new System.Drawing.Point(14, 41);
            this.tb_nama.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_nama.Name = "tb_nama";
            this.tb_nama.Size = new System.Drawing.Size(202, 32);
            this.tb_nama.TabIndex = 15;
            this.tb_nama.TextChanged += new System.EventHandler(this.tb_nama_TextChanged);
            // 
            // tb_isi
            // 
            this.tb_isi.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.tb_isi.Location = new System.Drawing.Point(14, 183);
            this.tb_isi.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tb_isi.Multiline = true;
            this.tb_isi.Name = "tb_isi";
            this.tb_isi.Size = new System.Drawing.Size(202, 112);
            this.tb_isi.TabIndex = 16;
            this.tb_isi.TextChanged += new System.EventHandler(this.tb_isi_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.Color.Black;
            this.label2.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(9, 155);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(31, 24);
            this.label2.TabIndex = 17;
            this.label2.Text = "Isi";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.Color.Black;
            this.label3.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(9, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(85, 24);
            this.label3.TabIndex = 18;
            this.label3.Text = "Kategori";
            // 
            // btn_tambah
            // 
            this.btn_tambah.Font = new System.Drawing.Font("Roboto", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.btn_tambah.Location = new System.Drawing.Point(119, 328);
            this.btn_tambah.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btn_tambah.Name = "btn_tambah";
            this.btn_tambah.Size = new System.Drawing.Size(97, 47);
            this.btn_tambah.TabIndex = 19;
            this.btn_tambah.Text = "Tambah";
            this.btn_tambah.UseVisualStyleBackColor = true;
            this.btn_tambah.Click += new System.EventHandler(this.btn_tambah_Click);
            // 
            // f_DetailNote
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Black;
            this.ClientSize = new System.Drawing.Size(234, 393);
            this.Controls.Add(this.btn_tambah);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.tb_isi);
            this.Controls.Add(this.tb_nama);
            this.Controls.Add(this.cb_kategori);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_simpan);
            this.Controls.Add(this.btn_hapus);
            this.Controls.Add(this.lb_totalChar);
            this.Controls.Add(this.label4);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "f_DetailNote";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Notes";
            this.Load += new System.EventHandler(this.f_DetailNote_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lb_totalChar;
        private System.Windows.Forms.Button btn_hapus;
        private System.Windows.Forms.Button btn_simpan;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox cb_kategori;
        private System.Windows.Forms.TextBox tb_nama;
        private System.Windows.Forms.TextBox tb_isi;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_tambah;
    }
}