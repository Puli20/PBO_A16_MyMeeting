﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MyMeeting
{
    public class DBInfo
    {
        string server = "localhost";
        string port = "5432";
        string userId = "postgres";
        string pass = "123456";
        string db = "mymeeting";

        public string getArg()
        {
            string arg = "Host=" + server + ";port=" + port + ";User Id=" + userId + ";Password=" + pass + ";Database=" + db + ";";
            return arg;
        }
    }
}
